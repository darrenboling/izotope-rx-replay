#!/bin/bash
# RX Replay — folder watcher. One pass: runs every job that's ready, then exits.
# launchd runs it every 20 seconds (see rxr-watch-install.sh). Works on macOS's own bash 3.2.
#
#   bash rxr-watch.sh "<watch folder>"
#
# The watch folder (normally in Dropbox) holds:
#   <project>/   a FOLDER dropped straight into the watch folder, or into Inbox/ (either works):
#                one song or a whole batch, the histories (.xml or .rxdoc) and the alts, in any
#                subfolders. Its name carries through: results go to Outbox/<project><suffix>/. Each alt
#                goes with the history it shares its name with ("D Inst.wav" → "D Mix RX.xml";
#                with one history, every alt goes with it). A treated main mix named like its
#                history is recognised and skipped.
#   Inbox/       the same, for anyone who prefers a drop folder. Loose audio and history files
#                dropped straight into Inbox or the watch folder are gathered into a folder
#                ("RX Replay <date time>") once they've stopped changing, and processed.
#   Processing/  the folder being worked on
#   Outbox/      <folder><suffix>/  the RX'd alts (and their histories, if chosen); logs/ holds
#                "RESULT - <status>.txt", rxreplay-result.json, rxreplay-log.txt and logs/<song>/
#   Original Sources/  the dropped folders that worked, with the date and time added
#   Failed/      folders that didn't, or only partly (Outbox/<folder>/ says why)
#
# A folder starts once its files (names and sizes) haven't changed for SETTLE_SECONDS, so a
# Dropbox upload still in progress isn't picked up, and once it holds both a history and audio:
# if either is missing it waits (the order files arrive in doesn't matter) for up to
# WAIT_MINUTES, then fails. Settings: <watch folder>/watch.conf, e.g.
#   SUFFIX=" - RX"
#   SAVE=none            (none, xml or rxdoc: the history saved with each export)
#   SETTLE_SECONDS=60
#   WAIT_MINUTES=30      (how long a folder waits for a missing history or audio)
set -u
BASE="${1:-}"
BASE="${BASE%/}"
[ -n "$BASE" ] && [ -d "$BASE" ] || { echo "usage: bash $0 \"<watch folder>\""; exit 2; }

SUFFIX=" - RX"; SAVE="none"; SETTLE_SECONDS=60; WAIT_MINUTES=30
# First run: write the settings file with the defaults, to edit later
[ -f "$BASE/watch.conf" ] || printf '%s\n' \
  '# RX Replay watcher settings' \
  'SUFFIX=" - RX"' \
  '# none, xml or rxdoc: the history saved beside each export' \
  'SAVE=none' \
  '# seconds a dropped folder must stay unchanged before it starts' \
  'SETTLE_SECONDS=60' \
  '# minutes a folder waits for a missing history (or audio) before it fails' \
  'WAIT_MINUTES=30' > "$BASE/watch.conf"
# Read the settings without running anything in the file (it may be in a shared folder)
if [ -f "$BASE/watch.conf" ]; then
  while IFS='=' read -r k v; do
    v="${v%$'\r'}"; v="${v%\"}"; v="${v#\"}"
    case "$k" in
      SUFFIX) SUFFIX="$v" ;;
      SAVE) case "$v" in none|xml|rxdoc) SAVE="$v" ;; esac ;;
      SETTLE_SECONDS) case "$v" in ''|*[!0-9]*) ;; *) SETTLE_SECONDS="$v" ;; esac ;;
      WAIT_MINUTES) case "$v" in ''|*[!0-9]*) ;; *) WAIT_MINUTES="$v" ;; esac ;;
    esac
  done < <(grep -E '^(SUFFIX|SAVE|SETTLE_SECONDS|WAIT_MINUTES)=' "$BASE/watch.conf")
fi

APP_NAME="RX Replay"
LOCAL="$HOME/Library/Application Support/RX Replay/Watch"
WORK="$LOCAL/Work"; STATE="$LOCAL/State"; LOG="$LOCAL/watch.log"
if [ -d "$BASE/Done" ] && [ ! -e "$BASE/Original Sources" ]; then mv "$BASE/Done" "$BASE/Original Sources"; fi   # older name
mkdir -p "$BASE/Inbox" "$BASE/Processing" "$BASE/Outbox" "$BASE/Original Sources" "$BASE/Failed" "$WORK" "$STATE"
find "$STATE" -type f -mtime +2 -delete 2>/dev/null

log() { echo "$(date '+%Y-%m-%d %H:%M:%S')  $*" >> "$LOG"; }

# "<path>", or "<path> (2)", "<path> (3)"… whichever doesn't exist yet
unique() {
  local p="$1" n=2
  while [ -e "$p" ]; do p="$1 ($n)"; n=$((n + 1)); done
  echo "$p"
}

# How many histories / audio files under a folder (extra find options after the folder)
n_hist() { find "$@" -type f ! -name '.*' \( -iname '*.xml' -o -iname '*.rxdoc' \) 2>/dev/null | wc -l | tr -d ' '; }
n_audio() {
  find "$@" -type f ! -name '.*' \( -iname '*.wav' -o -iname '*.wave' -o -iname '*.bwf' -o -iname '*.aif' -o -iname '*.aiff' \
    -o -iname '*.aifc' -o -iname '*.flac' -o -iname '*.w64' -o -iname '*.rf64' -o -iname '*.caf' \) 2>/dev/null | wc -l | tr -d ' '
}
# What a folder still lacks ("" = nothing)
missing() {
  local h a
  h=$(n_hist "$@"); a=$(n_audio "$@")
  if [ "$h" -eq 0 ] && [ "$a" -eq 0 ]; then echo "a history (.xml or .rxdoc) and audio files"
  elif [ "$h" -eq 0 ]; then echo "a history (.xml or .rxdoc)"
  elif [ "$a" -eq 0 ]; then echo "the audio files"
  fi
}
# Log a waiting message once (until it changes), so the log isn't filled every 20 seconds
note_once() {
  local f="$STATE/$(md5 -q -s "$1").note"
  if [ -f "$f" ] && [ "$(cat "$f")" = "$2" ]; then return; fi
  echo "$2" > "$f"
  log "$2"
}
# Seconds since a folder started waiting for something missing (starts the clock if new)
waited() {
  local f="$STATE/$(md5 -q -s "$1").wait" now first
  now=$(date +%s)
  [ -f "$f" ] || echo "$now" > "$f"
  read -r first < "$f"
  echo $((now - first))
}

lower_ext() { local e="${1##*.}"; echo "$e" | tr 'A-Z' 'a-z'; }
stem() { local b; b="$(basename "$1")"; echo "${b%.*}"; }

# Names and sizes of every file in a song folder (Dropbox keeps the original modification
# times, so those can't show whether an upload has finished)
signature() { (cd "$1" && find . -type f ! -name '.*' ! -name $'Icon\r' -exec stat -f '%z %N' {} + 2>/dev/null | sort | md5 -q); }

# Ready = has files, none empty, and the same names and sizes for SETTLE_SECONDS
ready() {
  local d="$1" key s now prev first
  key="$STATE/$(md5 -q -s "$d")"
  [ -n "$(find "$d" -type f ! -name '.*' | head -1)" ] || return 1
  if [ -n "$(find "$d" -type f ! -name '.*' -size 0 | head -1)" ]; then
    rm -f "$key"
    note_once "$d" "Waiting: $(find "$d" -type f ! -name '.*' -size 0 | wc -l | tr -d ' ') file(s) in \"$(basename "$d")\" haven't finished downloading (in Dropbox, make the watch folder available offline)."
    return 1
  fi
  s="$(signature "$d")"; now=$(date +%s)
  prev=""; first=0
  [ -f "$key" ] && read -r prev first < "$key"
  if [ "$s" != "$prev" ]; then echo "$s $now" > "$key"; return 1; fi
  [ $((now - first)) -ge "$SETTLE_SECONDS" ]
}

# Puts a plain-text result in Outbox/<song>/ (used when the app never ran)
fail_early() {
  local proc="$1" job="$2" msg="$3" out
  out="$(unique "$BASE/Outbox/$job$SUFFIX")"; mkdir -p "$out/logs"
  printf 'Status: failed\n\n%s\n' "$msg" > "$out/logs/RESULT - failed.txt"
  mv "$proc" "$(unique "$BASE/Failed/$job")"
  log "FAILED $job: $msg"
}

process() {
  local src="$1" job proc w f e from
  job="$(basename "$src")"
  from="$(dirname "$src")"                          # Inbox or the watch folder itself
  proc="$(unique "$BASE/Processing/$job")"
  mv "$src" "$proc" || { log "Couldn't move $job to Processing"; return; }
  rm -f "$STATE/$(md5 -q -s "$src")" "$STATE/$(md5 -q -s "$src").note" "$STATE/$(md5 -q -s "$src").wait"
  log "── $job: started"

  local histories=() files=() n_audio=0
  while IFS= read -r -d '' f; do
    case "$(lower_ext "$f")" in
      xml|rxdoc) histories+=("$f"); files+=("$f") ;;
      wav|wave|bwf|aif|aiff|aifc|flac|w64|rf64|caf) files+=("$f"); n_audio=$((n_audio + 1)) ;;
    esac
  done < <(find "$proc" -type f ! -name '.*' -print0)

  if [ "${#histories[@]}" -eq 0 ]; then
    fail_early "$proc" "$job" "No history (.xml or .rxdoc) arrived in the folder within $WAIT_MINUTES minutes."
    return
  fi
  if [ "$n_audio" -eq 0 ]; then
    fail_early "$proc" "$job" "No audio files arrived in the folder within $WAIT_MINUTES minutes."
    return
  fi

  # Work on local copies, off Dropbox (one flat folder; the app matches alts to songs by name)
  w="$WORK/$job $(date +%Y%m%d-%H%M%S)"
  mkdir -p "$w/in" "$w/out"
  for f in "${files[@]}"; do
    if [ -e "$w/in/$(basename "$f")" ]; then log "   two files named $(basename "$f"): only the first is used"; continue; fi
    cp -p "$f" "$w/in/" || { fail_early "$proc" "$job" "$(basename "$f") couldn't be copied (is the Inbox folder available offline in Dropbox?)."; rm -rf "$w"; return; }
  done
  log "   ${#histories[@]} histor$([ "${#histories[@]}" -eq 1 ] && echo y || echo ies), $n_audio audio file(s)"
  local args=(--batch "$w/in" --out "$w/out" --export-dir "$w/out"
              --unattended --quit-when-done --suffix "$SUFFIX" --save "$SAVE")

  open -n -W -a "$APP_NAME" --args "${args[@]}"

  local res="$w/out/rxreplay-result.json" status err
  status="$(plutil -extract status raw -o - "$res" 2>/dev/null)"
  [ -n "$status" ] || status="failed"
  err="$(plutil -extract error raw -o - "$res" 2>/dev/null)"

  if [ "$status" = "busy" ]; then
    # Another replay is running on this Mac: put the song back and try again later
    log "   busy (another replay is running): put back for the next pass"
    mv "$proc" "$(unique "$from/$job")"
    rm -rf "$w"
    return
  fi

  # Everything but the audio (and histories) goes in logs/, so the folder opens on the WAVs
  mkdir -p "$w/out/logs"
  [ -f "$w/out/rxreplay-log.txt" ] && mv "$w/out/rxreplay-log.txt" "$w/out/logs/"

  # A plain summary for people looking in Finder
  {
    echo "Status: $status"
    [ -n "$err" ] && echo "$err"
    echo
    local ns k n i m ms mx me sd sst
    ns="$(plutil -extract songs raw -o - "$res" 2>/dev/null)"
    case "$ns" in ''|*[!0-9]*) ns=0 ;; esac
    k=0
    while [ "$k" -lt "$ns" ]; do
      sd="$(basename "$(plutil -extract songs.$k.doc raw -o - "$res" 2>/dev/null)")"
      sst="$(plutil -extract songs.$k.status raw -o - "$res" 2>/dev/null)"
      echo "$sd: $sst"
      n="$(plutil -extract songs.$k.mixes raw -o - "$res" 2>/dev/null)"
      case "$n" in ''|*[!0-9]*) n=0 ;; esac
      i=0
      while [ "$i" -lt "$n" ]; do
        m="$(basename "$(plutil -extract songs.$k.mixes.$i.mix raw -o - "$res" 2>/dev/null)")"
        ms="$(plutil -extract songs.$k.mixes.$i.status raw -o - "$res" 2>/dev/null)"
        mx="$(plutil -extract songs.$k.mixes.$i.export raw -o - "$res" 2>/dev/null)"
        me="$(plutil -extract songs.$k.mixes.$i.error raw -o - "$res" 2>/dev/null)"
        if [ "$ms" = "success" ]; then echo "   OK      $m  →  $(basename "$mx")"
        else echo "   ${ms:-failed}  $m: ${me:-no details}"; fi
        i=$((i + 1))
      done
      k=$((k + 1))
    done
    n="$(plutil -extract unmatched raw -o - "$res" 2>/dev/null)"
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
      echo "NOT PROCESSED (no matching history)  $(basename "$(plutil -extract unmatched.$i raw -o - "$res" 2>/dev/null)")"
      i=$((i + 1))
    done
    n="$(plutil -extract notes raw -o - "$res" 2>/dev/null)"
    case "$n" in ''|*[!0-9]*) n=0 ;; esac
    i=0
    while [ "$i" -lt "$n" ]; do
      echo "Note: $(plutil -extract notes.$i raw -o - "$res" 2>/dev/null)"
      i=$((i + 1))
    done
    [ -f "$res" ] || echo "RX Replay didn't write a result (is it installed in Applications?)."
    echo
    echo "Details: rxreplay-result.json, rxreplay-log.txt and the <song> folders here"
  } > "$w/out/logs/RESULT - $status.txt"

  # Into Outbox in one go, the result last (so anything watching Outbox sees it complete)
  local out
  out="$(unique "$BASE/Outbox/$job$SUFFIX")"          # named like the exports: "<folder><suffix>"
  mkdir -p "$out"
  for f in "$w/out"/*; do
    [ -e "$f" ] || continue
    [ "$f" = "$res" ] && continue
    mv "$f" "$out/"
  done
  [ -f "$res" ] && mv "$res" "$out/logs/"

  if [ "$status" = "success" ]; then
    case "$job" in
      "RX Replay "*) mv "$proc" "$(unique "$BASE/Original Sources/$job")" ;;                    # already dated
      *) mv "$proc" "$(unique "$BASE/Original Sources/$job $(date '+%Y-%m-%d %H.%M.%S')")" ;;
    esac
  else mv "$proc" "$(unique "$BASE/Failed/$job")"; fi
  log "   $status${err:+: $err}  →  Outbox/$(basename "$out")"

  case "$w" in "$WORK"/*) rm -rf "$w" ;; esac      # the local copies (the results have moved out)
}

# Loose files: once they've sat still, gather them into one folder. In Inbox any file counts;
# straight in the watch folder only audio and histories do (watch.conf and the like stay put).
loose_files() {   # <folder> [extra find tests]
  local dir="$1"; shift
  if [ "$dir" = "$BASE" ]; then
    find "$dir" -maxdepth 1 -type f ! -name '.*' ! -name $'Icon\r' \( -iname '*.xml' -o -iname '*.rxdoc' \
      -o -iname '*.wav' -o -iname '*.wave' -o -iname '*.bwf' -o -iname '*.aif' -o -iname '*.aiff' -o -iname '*.aifc' \
      -o -iname '*.flac' -o -iname '*.w64' -o -iname '*.rf64' -o -iname '*.caf' \) "$@"
  else
    find "$dir" -maxdepth 1 -type f ! -name '.*' ! -name $'Icon\r' "$@"
  fi
}
gather_loose() {   # <folder>
  local dir="$1" lkey ls_sig lnow lprev lfirst lmiss gather overdue g where
  [ -n "$(loose_files "$dir" | head -1)" ] || return 0
  where="$([ "$dir" = "$BASE" ] && echo "the watch folder" || echo "Inbox")"
  lkey="$STATE/loose $(md5 -q -s "$dir")"
  if [ -n "$(loose_files "$dir" -size 0 | head -1)" ]; then rm -f "$lkey"; return 0; fi
  ls_sig="$(loose_files "$dir" -exec stat -f '%z %N' {} + 2>/dev/null | sort | md5 -q)"
  lnow=$(date +%s); lprev=""; lfirst=0
  [ -f "$lkey" ] && read -r lprev lfirst < "$lkey"
  if [ "$ls_sig" != "$lprev" ]; then echo "$ls_sig $lnow" > "$lkey"; return 0; fi
  [ $((lnow - lfirst)) -ge "$SETTLE_SECONDS" ] || return 0
  # Gather once there's a history and audio among them; until then wait (up to WAIT_MINUTES)
  lmiss="$(missing "$dir" -maxdepth 1)"
  gather=1; overdue=0
  if [ -n "$lmiss" ]; then
    if [ "$(waited "$dir")" -lt $((WAIT_MINUTES * 60)) ]; then
      note_once "$dir" "Waiting for $lmiss among the loose files in $where (up to $WAIT_MINUTES minutes)."
      gather=0
    else
      overdue=1
    fi
  fi
  [ "$gather" = 1 ] || return 0
  g="$(unique "$dir/RX Replay $(date '+%Y-%m-%d %H.%M.%S')")"
  mkdir -p "$g"
  loose_files "$dir" -exec mv {} "$g/" \;
  rm -f "$lkey" "$STATE/$(md5 -q -s "$dir").note" "$STATE/$(md5 -q -s "$dir").wait"
  echo "$(signature "$g") 0" > "$STATE/$(md5 -q -s "$g")"     # already settled: start it this pass
  [ "$overdue" = 1 ] && echo 0 > "$STATE/$(md5 -q -s "$g").wait"   # already waited: don't wait again
  log "Gathered the loose files in $where into \"$(basename "$g")\""
}
gather_loose "$BASE/Inbox"
gather_loose "$BASE"

# Project folders: in Inbox, or dropped straight into the watch folder. The watcher's own
# folders are never treated as projects.
for d in "$BASE/Inbox"/*/ "$BASE"/*/; do
  [ -d "$d" ] || continue
  d="${d%/}"
  case "$(basename "$d")" in Inbox|Processing|Outbox|"Original Sources"|Failed|Done) continue ;; esac
  ready "$d" || continue
  miss="$(missing "$d")"
  if [ -n "$miss" ] && [ "$(waited "$d")" -lt $((WAIT_MINUTES * 60)) ]; then
    note_once "$d" "Waiting for $miss in \"$(basename "$d")\" (up to $WAIT_MINUTES minutes)."
    continue
  fi
  process "$d"
done
exit 0
